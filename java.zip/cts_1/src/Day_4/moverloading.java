package Day_4;

public class moverloading {
public int add(int x,int y)
		{
			int z=x+y;
			return z;
		}
			public int add(int a,int b,int c)
			{
				int d=a+b+c;
				return d;
		}
			public static void main(String[] args)
			{
				moverloading m=new moverloading();
				System.out.println(m.add(3,5));
				System.out.println(m.add(3,5,3));

}
			}
