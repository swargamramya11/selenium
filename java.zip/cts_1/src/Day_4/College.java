package Day_4;
public class College {
public static void main(String[] args) {
int id;
float avg;
Student ramesh=new Student(88,90);
ramesh.calc_avg();
System.out.println("AVERAGE marks of ramesh "+ramesh.avg);

Student ram=new Student(67,35);
ram.calc_avg();
System.out.println("AVERAGE marks of ram "+ram.avg);
}
}
