package Day_4;

public class Student {
	int id;
	String name;
	int selenium;
	int java;
	float avg;
	public Student(int i, int j) {
		selenium=i;java=j;
	}
	public void calc_avg()
	{
		avg=(selenium+java)/2.0f;
	}
}

	


