package Day_4;
import java.util.Scanner;
public class clg 
{
	static int i,j;
	static String sid[][]={{"1","ramya"},{"2","latha"},{"3","janvi"},{"4","vamsi"},{"5","madhu"}}; 
	static int[][] marks={{2,44,55},{5,54,73},{4,65,88},{3,66,99},{1,88,90}}; 
	
public static int calc_avg(int a,int b)
	{
	int avg=(a+b)/2;
	return avg;
	}

public static int search1(int ssid)
	{
	for(i=0;i<5;i++)
			{
				int id= Integer.parseInt(sid[i][j]);
				if(ssid==id)
				{
					break;
				}
			}
	return i;
				}
public static int search2(int ssid)
	{
				for(i=0;i<5;i++)
				{
				if(ssid==marks[i][j])
					{
						break;
					}
				}
				return i;
	}

public static void main(String[] args) 
	{
		int i,j=0,p;
		
		System.out.println("Enter sid");
		Scanner input=new Scanner(System.in);
		int ssid=input.nextInt();
		
	    i=search1(ssid);
		p=search2(ssid);
		
		System.out.print(ssid+"\t");
		System.out.print(sid[i][j+1]+"\t");
		System.out.print(calc_avg(marks[p][j+1],marks[p][j+2]));
	}
}
