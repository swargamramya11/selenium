package Day_3;

import java.util.Scanner;

public class Pgm2
{

public static void main(String[] args) 
{
	int i,j=0,c;
	String emp[][]={{"1","ramya"},{"2","latha"},{"3","janvi"},{"4","vamsi"},{"5","madhu"}};
	System.out.println("Enter emp_id");
	Scanner input=new Scanner(System.in);
	String emp_id=input.nextLine();
	for(i=0;i<=4;i++)
	{
		c=emp_id.compareTo(emp[i][j]);
			if(c==0)
			{
				System.out.println(emp[i][j+1]);
				break;
			}
	}
}
}
