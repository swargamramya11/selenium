package Day_3;

public class Pgm3 {

	public static void main(String[] args) {
		int i;
		String s="mada";
		String rev="";
		for(i=s.length();i>0;i--)
		{
			rev=rev+s.charAt(i-1);
		}
		System.out.println(rev);
int c=s.compareTo(rev);
if(c==0)
	{
		System.out.println("string is palindrome");
	}
	else
	{
		System.out.println("string is not palindrome");
	}
	}
	}
