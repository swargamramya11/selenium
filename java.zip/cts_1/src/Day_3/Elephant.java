package Day_3;

public class Elephant extends Animal {
	int tusklen,trunklen;
	public void display_details()
	{
		super.display();
		System.out.println("tusklen: "+tusklen+ " trunklen: "+trunklen);
	}

}
