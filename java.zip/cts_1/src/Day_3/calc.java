package Day_3;

public class calc extends library {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		calc c=new calc();
		int d=c.add(1, 5);
		System.out.println("addition: "+d);
		int a=c.power(2, 3);
		System.out.println("power: "+a);
				}
}
