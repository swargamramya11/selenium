package Day_3;
import java.util.Scanner;
public class Pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int count=0;
		char s='a';
		System.out.println("ENTER CHARACTERS");
		Scanner input=new Scanner(System.in);
		while(s!='N')
		{
			s=input.next().charAt(0);
			if(s=='a'||s=='e'||s=='i'||s=='o'||s=='u'||s=='A'||s=='E'||s=='I'||s=='O'||s=='U')
			{
				count++;
			}
			
			}
		System.out.println("NO. OF VOWELS: "+count);
	}
}
