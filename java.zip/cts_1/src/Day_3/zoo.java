package Day_3;

public class zoo {

	public static void main(String[] args) {
		
		Elephant e1=new Elephant();
e1.height=3;
e1.weight=200;
e1.age=10;
e1.gender='m';
e1.color="grey";
e1.trunklen=3;
e1.tusklen=1;
e1.display_details();

	}

}
