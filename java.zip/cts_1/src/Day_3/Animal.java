package Day_3;

public class Animal {
	int age,weight,height;
	char gender;
	String color;
	
	public void display()
	{
		System.out.println("age: " +age+ " weight: " +weight+ " height: " +height+ " gender: " +gender+ " color: " +color);
	}

}