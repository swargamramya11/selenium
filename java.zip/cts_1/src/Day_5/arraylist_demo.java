package Day_5;

import java.util.ArrayList;

public class arraylist_demo {
	ArrayList<student> std_a1=new ArrayList<student>();
	public void create_a1()
	{
		student s1=new student("ramya",2,34,65);
		student s2=new student("ra",1,44,57);
		std_a1.add(s1);
		std_a1.add(s2);
	}
public void display_a1()
	{
		for(student s:std_a1)
		{
			
			System.out.println("name: " +s.name +" id: " +s.id  +" sel: " +s.selenium+" java: " +s.java+ " avg: " +s.avg);
		}
	}
	public static void main(String[] args) {
		arraylist_demo a=new arraylist_demo();
		a.create_a1();
		a.display_a1();
		
		}
}
