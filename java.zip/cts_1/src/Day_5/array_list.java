package Day_5;

import java.util.ArrayList;

public class array_list {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> str_a1=new ArrayList<String>();
		str_a1.add("1");
		str_a1.add("janvi");
		str_a1.add("ramya");
		str_a1.add("vamsi");
		str_a1.add("madhu");
		System.out.println("before insertion:"+str_a1);
		str_a1.add(3,"lavanya");
		System.out.println("after insertion:"+str_a1);
		str_a1.remove(3);
		System.out.println("after deletion:"+str_a1);
		str_a1.add(5,"soundarya");
		System.out.println("after insertion:"+str_a1);
for(String s:str_a1)
{
	System.out.println(s);
}
	
	}
}
