package Day_5;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class getexcel2 {

	public String read(String fname,String sname,int r,int c)
		{
		String s1="";
		File f=new File(fname);
		try 
		{
		FileInputStream fis = new FileInputStream(f);
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		XSSFSheet sh=wb.getSheet(sname);
		XSSFRow row=sh.getRow(r);
		XSSFCell cell=row.getCell(c);
		s1=cell.getStringCellValue();
		System.out.println(s1);
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
	    }
		return s1;
	}
		public void write(String fname,String sname,int r,int c,String str)
		{
		File f=new File(fname);
		try 
		{
		FileInputStream fis = new FileInputStream(f);
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		XSSFSheet sh=wb.getSheet(sname);
		XSSFRow row=sh.getRow(r);
		XSSFCell cell=row.getCell(c);
		
		cell.setCellValue(str);
		FileOutputStream fos=new FileOutputStream(f);
		wb.write(fos);
		} 
		catch (IOException e) 
		{
		e.printStackTrace();
	    }
	}
}

