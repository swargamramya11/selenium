package Day_5;

public class hdfc extends bank {
	float get_roi()
	{
		return 8.5f;
	}
}
