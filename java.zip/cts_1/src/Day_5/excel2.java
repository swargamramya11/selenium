package Day_5;

public class excel2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String Sheet1;
		getexcel2 g=new getexcel2();
		Sheet1=g.read("C:\\Users\\BLTuser.BLT0202\\Desktop\\CTS\\sr.xlsx", "Sheet1", 0, 0);
		g.write("C:\\Users\\BLTuser.BLT0202\\Desktop\\CTS\\sr.xlsx", "Sheet2",1,0,"i am ramya");
	}
}

