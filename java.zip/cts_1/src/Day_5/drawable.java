package Day_5;

public interface drawable {
	void draw();

}
