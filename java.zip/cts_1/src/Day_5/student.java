package Day_5;

public class student {
		int id;
		String name;
		int selenium;
		int java;
		float avg;
public student(String name,int id,int selenium,int java)
		{
			this.name=name;
			this.id=id;
			this.selenium=selenium;
			this.java=java;
			this.avg=clac_avg();
			}
public float clac_avg()
{
	float avg=(selenium+java)/2.0f;
	return avg;
}

}
