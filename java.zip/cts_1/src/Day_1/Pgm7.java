package Day_1;

public class Pgm7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i,x;
		for(i=1;i<=10;i++)
		{
			x=i%2;
			if(x==0)
			{
				System.out.print(i);
		}
			}
			

	}

}
