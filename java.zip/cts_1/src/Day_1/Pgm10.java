package Day_1;

public class Pgm10 {

	public static void main(String[] args) {
		int n=59138,sum=0,r;
		while(n>0)
		{
			r=n%10;
		if(r>5)
		{
			sum=sum+r;
		}
		n=n/10;
		}
		System.out.println(sum);
	}
	

}
