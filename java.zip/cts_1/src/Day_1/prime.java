package Day_1;

public class prime {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=5,i,count=0;
		for(i=2;i<n;i++)
		{
			if(n%i==0)
			{
				count++;
			}
			}
			if(count==0)
			{
				System.out.println("prime no.");
			}
				else
				{
					System.out.println("not prime no.");
		}
			
	}
}
