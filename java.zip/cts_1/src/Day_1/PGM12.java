package Day_1;

public class PGM12 {

	public static void main(String[] args) {
	int i,j;
	for(i=5,j=4;(i<=9)&&(j<=12);i++,j+=2)
	{
		System.out.println(i+"*"+j+"="+i*j);
	}
	
	}

}
