package Day_1;

public class Pgm16 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=506,r,s=0;
while(n>0)
{
	r=n%10;
	s=s*10+r;
	n=n/10;
	}
while(s>0)
{
	r=s%10;
		switch(r)
		{
		case 1:System.out.print("one ");
		       break;
		case 2:System.out.print("two ");
		 break;
		case 3:System.out.print("three ");
		 break;
		case 4:System.out.print("four");
		 break;
		case 5:System.out.print("five ");
		 break;
		case 6:System.out.print("six ");
		 break;
		case 7:System.out.print("seven ");
		 break;
		case 8:System.out.print("eigh ");
		 break;
		case 9:System.out.print("nine ");
		 break;
		case 0:System.out.print("zero ");
		 break;
		}
		s=s/10;
}
	}

}
