package Day_1;

public class Pgm15 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int i,count=0;
int n=1479;
while(n>0)
{
	n=n/10;
count++;
}
System.out.println(count);

	}

}
