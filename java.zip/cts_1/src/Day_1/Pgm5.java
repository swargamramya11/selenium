package Day_1;

public class Pgm5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
long a=1500000,x=0;
float t1,t2,t3;
float tax; 
//System.out.println("enter annual income");
if(a<=180000)
{
	System.out.println("interest to be paid is 0");	
}
else if((a>=180001)&&(a<=500000))
{
x=a-180000;
t1=x*0.1f;
tax=t1;
System.out.println("interest to be paid should be "+tax);
}
else if((a>=500001)&&(a<=800000))
{
x=a-500000;
t1=(320000*10)/100;
t2=x*0.2f;
tax=t1+t2;
System.out.println("interest to be paid should be "+tax);
}
else
{
x=a-800000;
t1=(320000*10)/100;
t2=(300000*20)/100;
t3=(x*30)/100;
tax=t1+t2+t3;
System.out.println("interest to be paid should be "+tax);
}
	}

}
