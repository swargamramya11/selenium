package Day_1;

public class Pgm9 {

	public static void main(String[] args) {
	int i=0,sum=0;
	for(i=1;i<=30;i++)
	{
		if((i%3==0)&&(i%15!=0))
		{
		
			System.out.println(" "+i);
			sum=sum+i;
	}
		}
	System.out.println(sum);
	}
}
