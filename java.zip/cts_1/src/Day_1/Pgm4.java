package Day_1;

public class Pgm4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a=13,b=9,c=4;
if(a<b)
{
if(a<c)
{
	System.out.println("a is smmallest no.");
}
	else
		System.out.println("c is smmallest no.");
}
else

	if(b<c)	
		System.out.println("b is smmallest no.");
	else
		System.out.println("c is smmallest no.");
		}
	}


