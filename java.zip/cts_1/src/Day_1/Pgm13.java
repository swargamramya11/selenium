package Day_1;

public class Pgm13 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int t1=1,t2=1,nextterm,i;
		for(i=1;i<=10;i++)
		{
			nextterm=t1+t2;
			t1=t2;
			t2=nextterm;
			System.out.print(t1 + "  ");
		}
	
		

	}

}
