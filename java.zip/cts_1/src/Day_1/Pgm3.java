package Day_1;

public class Pgm3 {

	public static void main(String[] args) {
		int a=3;
		int b=20;
		if(a>b)
		{
			System.out.println(a+" is greater than " +b);
		}
			else if(a==b)
			System.out.println(a+ " is equal to " +b);
			else
				System.out.println(a+ " is not greater than " +b);
				
	}

}
