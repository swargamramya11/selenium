package Day_1;

public class Pgm6 {

	public static void main(String[] args) {
		int i=10;
		switch(i)
		{
		case 10:
			System.out.println("number is ten");
			break;
		case 20:
			System.out.println("number is twenty");
			break;
		default:
			System.out.println("no number");
			break;
		}

	}

}
