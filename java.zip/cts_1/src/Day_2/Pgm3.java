package Day_2;

public class Pgm3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int[][] m={{7,8,4},{9,3,8}};
		int r,c,sum=0;
for(r=0;r<=1;r++)
	{
	for(c=0;c<=2;c++)
	{
		if(m[r][c]%2==0)
			sum=sum+m[r][c];
	}
	}
System.out.println(sum);
	}

}
