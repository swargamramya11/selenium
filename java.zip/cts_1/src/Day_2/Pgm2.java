package Day_2;

public class Pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i,sum=0;
		int[] marks={69,35,55,41,20,82,54,78,91,45};
		for(i=0;i<=9;i+=2)
		{
		if(marks[i]%2!=0)
			sum+=marks[i];
		}
	System.out.println(sum);
	}
	}
