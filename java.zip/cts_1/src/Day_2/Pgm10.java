package Day_2;

public class Pgm10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int m[]= {21,34,91,59,16,44,29,74,49,44};
		for(int i=0;i<=m.length;i++)
		{
			for(int j=i+1;j<m.length-1;j++)
			{
				if((m[i]+m[j])==65)
				{
					System.out.println("The sum of " +m[i]+ " & " +m[j]+ " is 65 ");
				}
			}
		}
	}
}
			
		
	


