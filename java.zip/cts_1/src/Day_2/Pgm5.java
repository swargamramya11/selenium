package Day_2;

public class Pgm5 {

	public static void main(String[] args) {
		int i,count=0;
		String s="i am learning core java";
		int l=s.length();
		for(i=0;i<=l;i++)
		{
			int p=s.indexOf(" ",i);
		if(p>=0)
		{
			i=p+1;
			count++;
		}
		}
	System.out.println(count);
	}

}
