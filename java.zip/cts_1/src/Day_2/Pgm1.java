package Day_2;

public class Pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int[] marks={67,35,54,41,20,82,54};
int i;
float avg,sum=0;
for(i=0;i<7;i++)
{
	sum=sum+marks[i];
}
avg=sum/i;
System.out.println(avg);
if(avg>=70)
	System.out.println("distinction and fc");
else if((avg>=60)&&(avg<70))
	System.out.println("distinction");
else if((avg>=50)&&(avg<60))
	System.out.println("sc");
	}

}
