package Day_2;

public class Pgm11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char c[];
		String s="hello how are you?";
		int i,freq=0;
		
		for(i=0;i<=s.length()-1;i++)
		{
			if(s.charAt(i)=='o')
				freq++;
			}
		System.out.println(freq);
	}

}
