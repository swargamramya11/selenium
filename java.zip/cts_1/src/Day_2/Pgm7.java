package Day_2;

public class Pgm7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10,b=0,c;
		int[] m={1,2,3,4};
		try
		{
			System.out.println("before");
			c=a/b;
			System.out.println("after");
			System.out.println(c);
			System.out.println(m[9]);
		}
		catch(ArithmeticException Ae)
		{
			System.out.println("in catch block");
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("aie block");
		}
System.out.println(m[2]);
	}

}
