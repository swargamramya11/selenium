package Day_2;

public class Pgm9 {

	public static void main(String[] args) {
		int i,j,max=0;
		int a[]={1,2,5,9};
		for(i=0;i<4;i++)
		{
			if(a[i]>max)
				max=a[i];
		}
	System.out.println(max);
	}
	}
