package Day_2;

public class Pgm6 {

	public static void main(String[] args) {
		int p=0,p1=0,p2=0,p3=0;
		String s1; 
		String s="i am learning core java";
		while(p3!=-1)
		{
			p=s.indexOf(" ",p1);
			p3=p;
			if(p==-1)
			p=s.length();
			s1=s.substring(p2,p);
			System.out.println(s1);
			p1=p+1;
			p2=p;
			}
		}
}
