package Day_2;

public class Pgm8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i,j,max=0;
		int a[][]={{7,8,4},{9,3,8},{6,99,5}};
		for(i=0;i<3;i++)
		{
			for(j=0;j<3;j++)
			{
				if(a[i][j]>max)
				max=a[i][j];
			}
			System.out.println(max);
		}
}
}
