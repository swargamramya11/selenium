package Day_2;

public class Pgm12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int r,c;
		int[][] a={{6,7,8,77},{53,98,22,23},{90,55,87,12,24}};
		int[][] b={{6,112,8,77},{32,98,22,23},{90,55,820,12,24}};
		int[][] p=new int[3][4];
		for(r=0;r<=2;r++)
		{
			for(c=0;c<=3;c++)
			{
				p[r][c]=a[r][c]+b[r][c];
				System.out.print(p[r][c]+" ");
			}
			System.out.println(" ");
		}
	}

}
